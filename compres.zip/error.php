<?php

include 'admin/config.php';
include 'templates/header.php';

?>

<main>
    <section class="grid-container">
        <h2 class="seccion_titulo">No se encontró lo que estabas buscando</h2>
    </section>
</main>

<?php

include 'templates/footer.php';

?>