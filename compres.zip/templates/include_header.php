<?php

include 'admin/config.php';
include 'admin/functions.php';

$conexion = conexion();

/*if (!$conexion) {
    header('Location: error.php');
}*/

?>