<?php

define('RUTA', 'https://mueblespr.000webhostapp.com/');

/* Datos de conexión */
define("BASEDATOS", "id16753527_pr_muebles");
define("USUARIO", "id16753527_root");
define("PASSWORD", "hgJa4z])fBIx+JX5");
define("SERVIDOR", "localhost");

/* Datos de encriptación */
define("KEY", "BB4SoftwarePRmuebles");
define("COD", "AES-128-ECB");

/* Configuración de productos */
$producto_config = array(
    'producto_a_mostrar' => 4,
    'carpeta_imagenes' => 'imagenes'
);

?>